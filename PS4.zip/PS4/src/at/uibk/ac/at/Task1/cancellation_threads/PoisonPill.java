package at.uibk.ac.at.Task1.cancellation_threads;

/**
 * Const integer value for a PoisonPill
 */
public class PoisonPill
{
    public static final Integer POIION_PILL = -1;
}
