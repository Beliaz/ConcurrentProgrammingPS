package uibk.ac.at.Task1;

/**
 * Created by flori on 06.12.2015.
 */
public interface Event {
}
