package uibk.ac.at.Task3;

/**
 * Created by flori on 21.11.2015.
 */
public interface LazyInit
{
    Object getInstance();
}
